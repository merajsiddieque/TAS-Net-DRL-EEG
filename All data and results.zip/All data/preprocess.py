import pandas as pd
import os
import numpy as np

input_dir = r"c:\Users\ASUS\Desktop\methodologies\All data"
files = [f for f in os.listdir(input_dir) if f.endswith('.csv') and 'new' not in f]

for file in files:
    file_path = os.path.join(input_dir, file)
    print(f"Processing {file}...")
    
    if file == 'method5.csv':
        df = pd.read_csv(file_path, header=None)
        # method5.csv has cols: epoch, reward, diversity_penalty, agent_similarity, recall
        df.columns = ['epoch', 'reward', 'diversity_penalty', 'agent_similarity', 'recall']
        df['loss'] = np.nan
    else:
        df = pd.read_csv(file_path)
        df.columns = df.columns.str.strip()
        
        # Rename loss
        if 'total_loss' in df.columns:
            df.rename(columns={'total_loss': 'loss'}, inplace=True)
        elif 'policy_loss' in df.columns:
            df.rename(columns={'policy_loss': 'loss'}, inplace=True)
        elif 'high_level_loss' in df.columns:
            df.rename(columns={'high_level_loss': 'loss'}, inplace=True)
            
        # Rename reward
        if 'reward_mean' in df.columns:
            df.rename(columns={'reward_mean': 'reward'}, inplace=True)
        elif 'reward_per_step' in df.columns:
            df.rename(columns={'reward_per_step': 'reward'}, inplace=True)
            
    # Keep only the requested columns in the specified order
    out_df = df[['epoch', 'loss', 'reward', 'recall']]
    
    output_path = os.path.join(input_dir, f"{file.split('.')[0]}_new.csv")
    out_df.to_csv(output_path, index=False)

print("Processing complete!")
